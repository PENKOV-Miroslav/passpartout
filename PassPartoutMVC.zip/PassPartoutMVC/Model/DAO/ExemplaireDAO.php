<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Exemplaire.php");

class ExemplaireDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
            //Methode d'insertion des données dans table Archives
            public function insert(Exemplaire $exemplaire) {
                $sql = "INSERT INTO exemplaire (id_exemplaire ,date_aquisition, code_type, id_personne) VALUES (:id_exemplaire, :date_aquisition, :code_type, :id_personne)";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_exemplaire', $exemplaire->getIdExemplaire());
                $stmt->bindValue(':date_aquisition', $exemplaire->getDateAquisition());
                $stmt->bindValue(':code_type', $exemplaire->getCodeType());
                $stmt->bindValue(':id_personne', $exemplaire->getIdPersonne());
                $stmt->execute();
            }

            // Méthode de mise à jour des archives
            public function update(Exemplaire $exemplaire) {
                $sql = "UPDATE exemplaire SET id_exemplaire = :id_exemplaire, date_aquisition = :date_aquisition, code_type = :code_type, id_personne = :id_personne WHERE id_exemplaire = :id_exemplaire";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_exemplaire', $exemplaire->getIdExemplaire());
                $stmt->execute();
            }
            

            // Méthode de suppression des archives
            public function delete(Exemplaire $exemplaire) {
                $sql = "DELETE FROM exemplaire WHERE id_exemplaire = :id_exemplaire";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_exemplaire', $exemplaire->getIdExemplaire());
                $stmt->execute();
            }

            // Méthode de recherche de toutes les archives
            public function findAll() {
            $sql = "SELECT * FROM exemplaire";
            $stmt = $this->connexion->prepare($sql);
            $stmt->execute();
            $exemplaires = [];
            while ($row = $stmt->fetch()) {
            $exemplaire = new Exemplaire();
            $exemplaire->setIdExemplaire($row['id_exemplaire']);
            $exemplaire->setDateAquisition($row['date_aquisition']);
            $exemplaire->setCodeType($row['code_type']);
            $exemplaire->setIdPersonne($row['id_personne']);
            $exemplaires[] = $exemplaire;
            }
            return $exemplaires;
            }
}