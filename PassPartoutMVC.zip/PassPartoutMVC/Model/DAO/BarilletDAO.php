<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Barillet.php");

class AssocierDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
            //Methode d'insertion des données dans table Archives
            public function insert(Barillet $barillet) {
                $sql = "INSERT INTO barillet (id_barillet ,code_clef, stock_clef, id_variure) VALUES (:id_barillet ,:code_clef, :stock_clef, :id_variure)";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_barillet', $barillet->getIdBarillet());
                $stmt->bindValue(':code_clef', $barillet->getCodeClef());
                $stmt->bindValue(':stock_clef', $barillet->getStockClef());
                $stmt->bindValue(':id_variure', $barillet->getIdVariure());
                $stmt->execute();
            }

            //Methode de recherche des données par id
            public function retrieve($barillet){
                $sql = "SELECT * FROM barillet WHERE id_barillet = ?";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindParam(1, $barillet);
                $stmt->execute();
            
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if(!$row){
                return null;
                }
            
                extract($row);
            
                $barillet = new Barillet();
                $barillet->setIdBarillet($barillet);
            
                return $barillet;
            }

            // Méthode de mise à jour des archives
            public function update(Barillet $barillet) {
                $sql = "UPDATE barillet SET id_barillet = :id_barillet, code_clef = :code_clef, stock_clef = :stock_clef, id_variure =:id_variure WHERE id_barillet = :id_barillet";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_barillet', $barillet->getIdBarillet());
                $stmt->execute();
            }
            

            // Méthode de suppression des archives
            public function delete(Barillet $barillet) {
                $sql = "DELETE FROM barillet WHERE id_barillet = :id_barillet";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_barillet', $barillet->getIdBarillet());
                $stmt->execute();
            }

            // Méthode de recherche de toutes les archives
            public function findAll() {
            $sql = "SELECT * FROM barillet";
            $stmt = $this->connexion->prepare($sql);
            $stmt->execute();
            $barillets = [];
            while ($row = $stmt->fetch()) {
            $barillet = new Barillet();
            $barillet->setIdBarillet($row['id_barillet']);
            $barillet->setCodeClef($row['code_clef']);
            $barillet->setStockClef($row['stock_clef']);
            $barillet->setIdVariure($row['id_variure']);
            $barillets[] = $barillet;
            }
            return $barillets;
            }
}