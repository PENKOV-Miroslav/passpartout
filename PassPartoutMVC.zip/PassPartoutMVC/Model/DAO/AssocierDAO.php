<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Associer.php");

class AssocierDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
            //Methode d'insertion des données dans table Archives
            public function insert(Associer $associer) {
                $sql = "INSERT INTO associer (id_salle ,id_porte) VALUES (:id_salle ,:id_porte)";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_salle', $associer->getSalle());
                $stmt->bindValue(':id_porte', $associer->getPorte());
                $stmt->execute();
            }

            // Méthode de mise à jour des archives
            public function update(Associer $associer) {
                $sql = "UPDATE associer SET id_salle = :id_salle, id_porte = :id_porte WHERE id_salle = :id_salle AND id_porte = :id_porte";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_salle', $associer->getSalle());
                $stmt->bindValue(':id_porte', $associer->getPorte());
                $stmt->execute();
            }

            // Méthode de suppression des archives
            public function delete(Associer $associer) {
                $sql = "DELETE FROM associer WHERE id_salle = :id_salle AND id_porte = :id_porte";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_salle', $associer->getSalle());
                $stmt->bindValue(':id_porte', $associer->getPorte());
                $stmt->execute();
            }

            // Méthode de recherche de toutes les archives
            public function findAll() {
            $sql = "SELECT * FROM associer";
            $stmt = $this->connexion->prepare($sql);
            $stmt->execute();
            $associers = [];
            while ($row = $stmt->fetch()) {
            $associer = new Associer();
            $associer->setSalle($row['id_salle']);
            $associer->setPorte($row['id_porte']);
            $associers[] = $associer;
            }
            return $associers;
            }
}