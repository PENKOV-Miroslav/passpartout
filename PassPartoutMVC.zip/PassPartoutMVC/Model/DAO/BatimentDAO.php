<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Batiment.php");

class BatimentDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
            //Methode d'insertion des données dans table Archives
            public function insert(Batiment $batiment) {
                $sql = "INSERT INTO batiment (id_batiment ,nom_batiment) VALUES (:id_batiment ,:nom_batiment)";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_batiment', $batiment->getIdBatiment());
                $stmt->bindValue(':nom_batiment', $batiment->getNomBatiment());
                $stmt->execute();
            }

            // Méthode de mise à jour des archives
            public function update(Batiment $batiment) {
                $sql = "UPDATE barillet SET id_batiment = :id_batiment, nom_batiment = :nom_batiment WHERE id_batiment = :id_batiment";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_batiment', $barillet->getIdBatiment());
                $stmt->execute();
            }
            

            // Méthode de suppression des archives
            public function delete(Batiment $batiment) {
                $sql = "DELETE FROM batiment WHERE id_batiment = :id_batiment";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_batiment', $batiment->getIdBatiment());
                $stmt->execute();
            }

            // Méthode de recherche de toutes les archives
            public function findAll() {
            $sql = "SELECT * FROM batiment";
            $stmt = $this->connexion->prepare($sql);
            $stmt->execute();
            $batiments = [];
            while ($row = $stmt->fetch()) {
            $batiment = new Batiment();
            $batiment->setIdBatiment($row['batiment']);
            $batiment->setNomBatiment($row['nom_batiment']);

            $batiments[] = $batiment;
            }
            return $batiments;
            }
}