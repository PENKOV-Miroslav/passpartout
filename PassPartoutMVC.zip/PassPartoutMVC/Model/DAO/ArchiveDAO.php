<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Archive.php");

class AppartenirDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
            //Methode d'insertion des données dans table Archives
            public function insert(Archive $archive) {
                $sql = "INSERT INTO archivage (id_archive ,date_acquisition, date_rendu, id_exemplaire, id_personne) VALUES (:id_archive ,:date_acquisition,:date_rendu,:id_exemplaire,:id_personne)";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_archive', $archive->getIdArchive());
                $stmt->bindValue(':date_acquisition', $archive->getDateAquisition());
                $stmt->bindValue(':date_rendu', $archive->getDateRendu());
                $stmt->bindValue(':id_exemplaire', $archive->getIdExemplaire());
                $stmt->bindValue(':id_personne', $archive->getIdPersonne());
                $stmt->execute();
            }

            // Méthode de mise à jour des archives
            public function update(Archive $archive) {
                $sql = "UPDATE archivage SET id_archive = :id_archive, date_acquisition = :date_acquisition, date_rendu = :date_rendu, id_exemplaire = :id_exemplaire,id_personne = :id_personne WHERE id_archive = :id_archive";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_archive', $archive->getIdArchive());
                $stmt->bindValue(':date_acquisition', $archive->getDateAquisition());
                $stmt->bindValue(':date_rendu', $archive->getDateRendu());
                $stmt->bindValue(':id_exemplaire', $archive->getIdExemplaire());
                $stmt->bindValue(':id_personne', $archive->getIdPersonne());
                $stmt->execute();
            }

            // Méthode de suppression des archives
            public function delete(Archive $archive) {
                $sql = "DELETE FROM archivage WHERE id_archive = :id_archive";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_archive', $archive->getIdArchive());
                $stmt->execute();
            }

            // Méthode de recherche de toutes les archives
            public function findAll() {
            $sql = "SELECT * FROM archivage";
            $stmt = $this->connexion->prepare($sql);
            $stmt->execute();
            $archivages = [];
            while ($row = $stmt->fetch()) {
            $archivage = new Archive();
            $archivage->setIdArchive($row['id_archive']);
            $archivages[] = $archivage;
            }
            return $archivages;
            }
}