<?php
class Salle{

    private $id_salle;
    private $nom_salle; 
    private $id_batiment;

    public function __construct($id_salle,$nom_salle,$id_batiment) {
        $this->id_salle = $id_salle;
        $this->nom_salle = $nom_salle;
        $this->id_batiment = $id_batiment;
    }

    public function getSalle(){
        return $this->id_salle;
    }

    public function setSalle($id_salle){
        $this->id_salle = $id_salle;
    }

    public function getNomSalle(){
        return $this->nom_salle;
      }
    
      public function setNomSalle($nom_salle){
        $this->nom_salle = $nom_salle;
      }

      public function getIdBatiment(){
        return $this->id_batiment;
      }
    
      public function setIdBatiment($id_batiment){
        $this->id_batiment = $id_batiment;
      }


}