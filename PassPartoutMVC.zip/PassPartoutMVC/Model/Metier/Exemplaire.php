<?php
class Exemplaire{
    private $id_exemplaire;
    private $date_aquisition;
    private $code_type;
    private $id_personne;

    public function __construct($id_exemplaire, $date_aquisition, $code_type, $id_personne) {
        $this->id_exemplaire = $id_exemplaire;
        $this->date_aquisition = $date_aquisition;
        $this->code_type = $code_type;
        $this->id_personne = $id_personne;

    }
      
        public function getIdExemplaire(){
          return $this->id_exemplaire;
        }
      
        public function setIdExemplaire($id_exemplaire){
          $this->id_exemplaire = $id_exemplaire;
        }

        public function getDateAquisition(){
            return $this->date_aquisition;
          }
        
          public function setDateAquisition($date_aquisition){
            $this->date_aquisition = $date_aquisition;
          }

          public function getCodeType(){
            return $this->code_type;
          }
        
          public function setCodeType($code_type){
            $this->code_type = $code_type;
          }

          public function getIdPersonne(){
            return $this->id_personne;
          }
        
          public function setIdPersonne($id_personne){
            $this->id_personne = $id_personne;
          }
}