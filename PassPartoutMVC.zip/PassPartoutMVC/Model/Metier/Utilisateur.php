<?php
class Utilisateur extends Personne {
   protected $login_hash;
   protected $mdp_hash;
   protected $id_role;
   
   public function __construct($id_personne ,$nom, $prenom, $numTelephone, $email, $adresse, $code_postale, $login_hash, $mdp_hash, $id_role) {
      parent::__construct($id_personne ,$nom, $prenom, $numTelephone, $email, $adresse, $code_postale);
      $this->login_hash = $login_hash;
      $this->mdp_hash = $mdp_hash;
      $this->id_role = $id_role;
   }

   public function getLogin(){
    return $this->login_hash;
  }

  public function setLogin($login_hash){
    $this->login_hash = $login_hash;
  }

  public function getMdp(){
    return $this->mdp_hash;
  }

  public function setmdp($mdp_hash){
    $this->mdp_hash = $mdp_hash;
  }

  public function getRole(){
    return $this->id_role;
  }

  public function setmdp($id_role){
    $this->id_role = $id_role;
  }
}