<?php

class Variure {
    private $id_variure;
    private $libelle_variure;


    public function __construct($id_variure ,$libelle_variure) {
        $this->id_variure = $id_variure;
        $this->libelle_variure = $libelle_variure;

    }
      
        public function getIdVariure(){
          return $this->id_variure;
        }
      
        public function setIdVariure($id_variure){
          $this->id_variure = $id_variure;
        }
      
        public function getLibelleVariure(){
          return $this->libelle_variure;
        }
      
        public function setLibelleVariure($libelle_variure){
          $this->libelle_variure = $libelle_variure;
        }
      }