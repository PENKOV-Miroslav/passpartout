<?php
class TypeExemplaire{
    
    private $code_type;
    private $type_libelle;


    public function __construct($code_type ,$type_libelle) {
        $this->code_type = $code_type;
        $this->type_libelle = $type_libelle;
    }
      
        public function getCodeType(){
          return $this->code_type;
        }
      
        public function setCodeType($code_type){
          $this->code_type = $code_type;
        }

        public function getTypeLibelle(){
            return $this->type_libelle;
          }
        
          public function setTypeLibelle($type_libelle){
            $this->type_libelle = $type_libelle;
          }


}