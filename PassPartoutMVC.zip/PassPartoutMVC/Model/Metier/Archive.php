<?php
class Archive{
    private $id_archive;
    private $date_aquisition;
    private $date_rendu;
    private $id_exemplaire;
    private $id_personne;

    public function __construct($id_archive ,$date_aquisition, $date_rendu, $id_exemplaire, $id_personne) {
        $this->id_archive = $id_archive;
        $this->date_aquisition = $date_aquisition;
        $this->date_rendu = $date_rendu;
        $this->id_exemplaire = $id_exemplaire;
        $this->id_personne = $id_personne;

    }
      
        public function getIdArchive(){
          return $this->id_archive;
        }
      
        public function setIdArchive($id_archive){
          $this->id_archive = $id_archive;
        }

        public function getDateAquisition(){
            return $this->date_aquisition;
          }
        
          public function setDateAquisition($date_aquisition){
            $this->date_aquisition = $date_aquisition;
          }

          public function getDateRendu(){
            return $this->date_rendu;
          }
        
          public function setDateRendu($date_rendu){
            $this->date_rendu = $date_rendu;
          }

          public function getIdExemplaire(){
            return $this->id_exemplaire;
          }
        
          public function setIdExemplaire($id_exemplaire){
            $this->id_exemplaire = $id_exemplaire;
          }

          public function getIdPersonne(){
            return $this->id_personne;
          }
        
          public function setIdPersonne($id_personne){
            $this->id_personne = $id_personne;
          }
}