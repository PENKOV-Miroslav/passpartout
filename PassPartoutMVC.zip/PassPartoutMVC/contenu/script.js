function monMenu() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

$(document).ready(function($) {
  $('.links').click(function() {
    $("#myTopnav").removeClass("responsive");
  });
});


function loadGeneral(content) {

  $(document).ready(function(){
      switch (content){
        case 'home':
            console.log("chargement Acceuil");
            $("#contenu-ajax").load("Home.php");
        break;
        case 'key':
            console.log("chargement GestionCle");
            $("#contenu-ajax").load("GestionCle.php");
        break;
        case 'user':
            console.log("chargement GestionUser");
            $("#contenu-ajax").load("Gestionuser.php");
        break;
        case 'archives':
            console.log("chargement Archives");
            $("#contenu-ajax").load("Archives.php");
        break;
      }
   
  });
}