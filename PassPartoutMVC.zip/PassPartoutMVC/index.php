<?php

session_start();

if(isset($_GET["action"])){
    $action = $_GET["action"];
}
else{
    $action = "init";
}
$Controller = "Controller/".$action.".php";
Include ($Controller);

$Vue = "Vue/".$vue.".php";
Include ($Vue);
?>