<div class="tabButtons">

    <button class="button-classic">créer un utilisateur</button>
    <button class="button-classic">sélectionner un utilisateur</button>
    <button class="button-classic">modifier un utilisateur</button>
    <button class="button-classic">supprimer un utilisateur</button>

</div>