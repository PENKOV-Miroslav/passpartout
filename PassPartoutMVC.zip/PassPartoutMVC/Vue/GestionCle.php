<div class="tabButtons">

    <button class="button-classic">ajouter une clef</button>
    <button class="button-classic">sélectionner une clef</button>
    <button class="button-classic">supprimer une clef</button>

</div>