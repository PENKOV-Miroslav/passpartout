<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="../contenu/jquery-3.6.1.min.js"></script>
  <script src="../contenu/script.js"></script>
    <link rel="stylesheet"   href="../contenu/style.css">
    <title>Accueil</title>
</head>
<body>
    <div class="conteneur-menu">
      <div class="topnav" id="myTopnav">
          <button class="fa fa-home links" aria-hidden="true" onclick="loadGeneral('home')"></button>
          <button class="fa fa-key links" aria-hidden="true" onclick="loadGeneral('key')"></button>
          <button class="fa fa-users links" aria-hidden="true" onclick="loadGeneral('user')"></button>
          <button class="fa fa-list-alt" aria-hidden="true" onclick="loadGeneral('archives')"></button>
          <button class="fa fa-sign-out " aria-hidden="true"></button>
          <a href="javascript:void(0);" class="icon" onclick="monMenu()">
            <i class="fa fa-bars"></i>
          </a>
      </div>
    </div>  

    <div class="conteneur-general">
      <div id="contenu-ajax">
        <p>le contenu va changer suivant la rubrique choisie</p>
      </div>
    </div>
</body>
</html>