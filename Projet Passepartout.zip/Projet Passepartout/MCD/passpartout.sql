-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : lun. 03 avr. 2023 à 13:49
-- Version du serveur : 5.7.39
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `passpartout`
--

-- --------------------------------------------------------

--
-- Structure de la table `APPARTENIR`
--

CREATE TABLE `APPARTENIR` (
  `id_barrillet` int(11) NOT NULL,
  `id_exemplaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ARCHIVAGE`
--

CREATE TABLE `ARCHIVAGE` (
  `id_archive` int(11) NOT NULL,
  `date_acquisition` date NOT NULL,
  `date_rendu` date NOT NULL,
  `id_exemplaire` int(11) NOT NULL,
  `id_personne` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ASSOCIER`
--

CREATE TABLE `ASSOCIER` (
  `id_salle` int(11) NOT NULL,
  `id_porte` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `BARILLET`
--

CREATE TABLE `BARILLET` (
  `id_barrillet` int(11) NOT NULL,
  `code_clef` varchar(50) NOT NULL,
  `stock_clef` int(11) NOT NULL,
  `id_variure` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `BATIMENT`
--

CREATE TABLE `BATIMENT` (
  `id_batiment` int(11) NOT NULL,
  `nom_batiment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `EXEMPLAIRE`
--

CREATE TABLE `EXEMPLAIRE` (
  `id_exemplaire` int(11) NOT NULL,
  `date_acquisition` date NOT NULL,
  `code_type` varchar(50) NOT NULL,
  `id_personne` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `PERSONNE`
--

CREATE TABLE `PERSONNE` (
  `id_personne` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `numTelephone` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `code_postal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `PORTE`
--

CREATE TABLE `PORTE` (
  `id_porte` varchar(50) NOT NULL,
  `id_barrillet` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `POSSESSEUR_DE_CLEF`
--

CREATE TABLE `POSSESSEUR_DE_CLEF` (
  `id_personne` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `POUVOIR`
--

CREATE TABLE `POUVOIR` (
  `id_barrillet` int(11) NOT NULL,
  `id_personne` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `Roles`
--

CREATE TABLE `Roles` (
  `id_role` varchar(50) NOT NULL,
  `libelle` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `SALLE`
--

CREATE TABLE `SALLE` (
  `id_salle` int(11) NOT NULL,
  `nom_salle` varchar(50) NOT NULL,
  `id_batiment` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `type_exemplaire`
--

CREATE TABLE `type_exemplaire` (
  `code_type` varchar(50) NOT NULL,
  `type_libelle` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `UTILISATEUR`
--

CREATE TABLE `UTILISATEUR` (
  `id_personne` int(11) NOT NULL,
  `login_hash` varchar(50) NOT NULL,
  `mdp_hash` varchar(50) NOT NULL,
  `id_role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `VARIURE`
--

CREATE TABLE `VARIURE` (
  `id_variure` varchar(50) NOT NULL,
  `libelle_variure` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `APPARTENIR`
--
ALTER TABLE `APPARTENIR`
  ADD PRIMARY KEY (`id_barrillet`,`id_exemplaire`),
  ADD KEY `id_exemplaire` (`id_exemplaire`);

--
-- Index pour la table `ARCHIVAGE`
--
ALTER TABLE `ARCHIVAGE`
  ADD PRIMARY KEY (`id_archive`),
  ADD KEY `id_exemplaire` (`id_exemplaire`),
  ADD KEY `id_personne` (`id_personne`);

--
-- Index pour la table `ASSOCIER`
--
ALTER TABLE `ASSOCIER`
  ADD PRIMARY KEY (`id_salle`,`id_porte`),
  ADD KEY `id_porte` (`id_porte`);

--
-- Index pour la table `BARILLET`
--
ALTER TABLE `BARILLET`
  ADD PRIMARY KEY (`id_barrillet`),
  ADD KEY `id_variure` (`id_variure`);

--
-- Index pour la table `BATIMENT`
--
ALTER TABLE `BATIMENT`
  ADD PRIMARY KEY (`id_batiment`);

--
-- Index pour la table `EXEMPLAIRE`
--
ALTER TABLE `EXEMPLAIRE`
  ADD PRIMARY KEY (`id_exemplaire`),
  ADD KEY `code_type` (`code_type`),
  ADD KEY `id_personne` (`id_personne`);

--
-- Index pour la table `PERSONNE`
--
ALTER TABLE `PERSONNE`
  ADD PRIMARY KEY (`id_personne`);

--
-- Index pour la table `PORTE`
--
ALTER TABLE `PORTE`
  ADD PRIMARY KEY (`id_porte`),
  ADD KEY `id_barrillet` (`id_barrillet`);

--
-- Index pour la table `POSSESSEUR_DE_CLEF`
--
ALTER TABLE `POSSESSEUR_DE_CLEF`
  ADD PRIMARY KEY (`id_personne`);

--
-- Index pour la table `POUVOIR`
--
ALTER TABLE `POUVOIR`
  ADD PRIMARY KEY (`id_barrillet`,`id_personne`),
  ADD KEY `id_personne` (`id_personne`);

--
-- Index pour la table `Roles`
--
ALTER TABLE `Roles`
  ADD PRIMARY KEY (`id_role`);

--
-- Index pour la table `SALLE`
--
ALTER TABLE `SALLE`
  ADD PRIMARY KEY (`id_salle`),
  ADD KEY `id_batiment` (`id_batiment`);

--
-- Index pour la table `type_exemplaire`
--
ALTER TABLE `type_exemplaire`
  ADD PRIMARY KEY (`code_type`);

--
-- Index pour la table `UTILISATEUR`
--
ALTER TABLE `UTILISATEUR`
  ADD PRIMARY KEY (`id_personne`),
  ADD KEY `id_role` (`id_role`);

--
-- Index pour la table `VARIURE`
--
ALTER TABLE `VARIURE`
  ADD PRIMARY KEY (`id_variure`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `APPARTENIR`
--
ALTER TABLE `APPARTENIR`
  ADD CONSTRAINT `appartenir_ibfk_1` FOREIGN KEY (`id_barrillet`) REFERENCES `BARILLET` (`id_barrillet`),
  ADD CONSTRAINT `appartenir_ibfk_2` FOREIGN KEY (`id_exemplaire`) REFERENCES `EXEMPLAIRE` (`id_exemplaire`);

--
-- Contraintes pour la table `ARCHIVAGE`
--
ALTER TABLE `ARCHIVAGE`
  ADD CONSTRAINT `archivage_ibfk_1` FOREIGN KEY (`id_exemplaire`) REFERENCES `EXEMPLAIRE` (`id_exemplaire`),
  ADD CONSTRAINT `archivage_ibfk_2` FOREIGN KEY (`id_personne`) REFERENCES `POSSESSEUR_DE_CLEF` (`id_personne`);

--
-- Contraintes pour la table `ASSOCIER`
--
ALTER TABLE `ASSOCIER`
  ADD CONSTRAINT `associer_ibfk_1` FOREIGN KEY (`id_salle`) REFERENCES `SALLE` (`id_salle`),
  ADD CONSTRAINT `associer_ibfk_2` FOREIGN KEY (`id_porte`) REFERENCES `PORTE` (`id_porte`);

--
-- Contraintes pour la table `BARILLET`
--
ALTER TABLE `BARILLET`
  ADD CONSTRAINT `barillet_ibfk_1` FOREIGN KEY (`id_variure`) REFERENCES `VARIURE` (`id_variure`);

--
-- Contraintes pour la table `EXEMPLAIRE`
--
ALTER TABLE `EXEMPLAIRE`
  ADD CONSTRAINT `exemplaire_ibfk_1` FOREIGN KEY (`code_type`) REFERENCES `type_exemplaire` (`code_type`),
  ADD CONSTRAINT `exemplaire_ibfk_2` FOREIGN KEY (`id_personne`) REFERENCES `POSSESSEUR_DE_CLEF` (`id_personne`);

--
-- Contraintes pour la table `PORTE`
--
ALTER TABLE `PORTE`
  ADD CONSTRAINT `porte_ibfk_1` FOREIGN KEY (`id_barrillet`) REFERENCES `BARILLET` (`id_barrillet`);

--
-- Contraintes pour la table `POSSESSEUR_DE_CLEF`
--
ALTER TABLE `POSSESSEUR_DE_CLEF`
  ADD CONSTRAINT `possesseur_de_clef_ibfk_1` FOREIGN KEY (`id_personne`) REFERENCES `PERSONNE` (`id_personne`);

--
-- Contraintes pour la table `POUVOIR`
--
ALTER TABLE `POUVOIR`
  ADD CONSTRAINT `pouvoir_ibfk_1` FOREIGN KEY (`id_barrillet`) REFERENCES `BARILLET` (`id_barrillet`),
  ADD CONSTRAINT `pouvoir_ibfk_2` FOREIGN KEY (`id_personne`) REFERENCES `PERSONNE` (`id_personne`);

--
-- Contraintes pour la table `SALLE`
--
ALTER TABLE `SALLE`
  ADD CONSTRAINT `salle_ibfk_1` FOREIGN KEY (`id_batiment`) REFERENCES `BATIMENT` (`id_batiment`);

--
-- Contraintes pour la table `UTILISATEUR`
--
ALTER TABLE `UTILISATEUR`
  ADD CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`id_personne`) REFERENCES `PERSONNE` (`id_personne`),
  ADD CONSTRAINT `utilisateur_ibfk_2` FOREIGN KEY (`id_role`) REFERENCES `Roles` (`id_role`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
