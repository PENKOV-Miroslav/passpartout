var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: ""
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Vous êtes connecté");

  var sql = "USE maBase2";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("BDD selectionnée");
  });

  var sql = "INSERT INTO clients (nom, adresse) VALUES ('JaimeLesOrdinateurs S.A.', '1, rue des plantes en pots')";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Enregistrement inséré");
  });

  var sql = "SELECT * FROM clients";
  con.query(sql, function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });

});