<?php

session_start();

if(isset($_GET["action"])){
    $action = $_GET["action"];
}
else{
    $action = "init";
}
$scriptAction = "Controller/".$action.".php";
Include ($scriptAction);

$scriptVue = "Vue/".$etat.".php";
Include ($scriptVue);
?>