function monMenu() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

$(document).ready(function($) {
  $('.links').click(function() {
    $("#myTopnav").removeClass("responsive");
  });
});


function loadGeneral() {

  var ContentChange = document.getElementById("myTopnav").value;
  $(document).ready(function(){
      switch (ContentChange){
          case 'home':
              console.log("re-chargement page");
              $("#contenu-ajax").load("accueil.html");
          break;
          case 'key':
              console.log("chargement GestionCle");
              $("#contenu-ajax").load("GestionCle.html");
          break;
          case 'user':
              console.log("chargement gestionUser");
              $("#contenu-ajax").load("Gestionuser.html");
              break;

      }
   
  });
}