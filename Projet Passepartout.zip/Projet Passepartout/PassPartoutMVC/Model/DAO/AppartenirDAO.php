<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Appartenir.php");

class AppartenirDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
            //methode d'insertion des données
            public function insert(Appartenir $appartenir) {
                $sql = "INSERT INTO appartenir (id_barillet, id_exemplaire) VALUES (:id_barillet, :id_exemplaire)";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_barillet', $appartenir->getIdProjet());
                $stmt->bindValue(':id_exemplaire', $appartenir->getIdUtilisateur());
                $stmt->execute();
                $appartenir->setId($this->pdo->lastInsertId());
            }
            //methode de selection par les identifiant des barillets
            public function retrieve($id_barillet) {
               $sql = "SELECT * FROM appartenir WHERE id_barillet = :id_barillet";
               $stmt = $this->connexion->prepare($sql);
               $stmt->bindValue(':id_barillet', $id_barillet);
               $stmt->execute();
               $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
               $appartenirs = array();
               foreach ($rows as $row) {
                  $appartenir = new Appartenir($row['id_barillet'], $row['id_exemplaire']);
                  $appartenir->setIdBarillet($row['id_barillet']);
                  $appartenirs[] = $appartenir;
               }
               return $appartenirs;
            }

            // Méthode de mise à jour
            public function update(Appartenir $appartenir) {
                $sql = "UPDATE appartenir SET id_barillet = :id_barillet, id_exemplaire = :id_exemplaire WHERE id_barillet = :id_barillet";
                $stmt = $this->connexion->prepare($sql);
                $stmt->bindValue(':id_barillet', $appartenir->getIdBarillet());
                $stmt->bindValue(':id_exemplaire', $appartenir->getIdExemplaire());
                $stmt->execute();
            }


}
    
      
