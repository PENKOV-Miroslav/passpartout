<?php
require ("./Model/BDD/ConnexionBDD.php");
require ("./Model/Metier/Variure.php");

class VariureDAO {

    $bdd = new ConnexionBDD();
    $connexion = $bdd->getConnexion();
      
      //methode d'insertion des données
        public function create(Variure $variure){
          $query = "INSERT INTO variure (libelle_variure) VALUES (:libelle_variure)";
          $stmt = $this->connexion->prepare($query);
      
          $libelle_variure = $variure->getLibelleVariure();
          $stmt->bindParam(":libelle_variure", $libelle_variure);
      
          if($stmt->execute()){
            $variure->setIdVariure($this->connexion->lastInsertId());
            return true;
          }
      
          return false;
        }

        //methode de recherche des données par id
        public function retrieve($id_variure){
            $query = "SELECT * FROM variure WHERE id_variure = ?";
            $stmt = $this->connexion->prepare($query);
            $stmt->bindParam(1, $id_variure);
            $stmt->execute();
        
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if(!$row){
              return null;
            }
        
            extract($row);
        
            $variure = new Variure();
            $variure->setIdVariure($id_variure);
            $variure->setLibelleVariure($libelle_variure);
        
            return $variure;
          }


          //methode de update des données par l'id de la variure
        public function update(Variure $variure){
          $query = "UPDATE variure SET libelle_variure = :libelle_variure WHERE id_variure = :id_variure";
          $stmt = $this->connexion->prepare($query);
      
          $id_variure = $variure->getIdVariure();
          $libelle_variure = $variure->getLibelleVariure();
      
          $stmt->bindParam(":id_variure", $id_variure);
          $stmt->bindParam(":libelle_variure", $libelle_variure);
      
          return $stmt->execute();
        }
      

        //supprimer une variure suivant sont id
        public function delete($id_variure){
          $query = "DELETE FROM variure WHERE id_variure = ?";
          $stmt = $this->connexion->prepare($query);
          $stmt->bindParam(1, $id_variure);
          return $stmt->execute();
        }


        // récupérer tous les enregistrements pour les afficher par la suite
        public function findAll(){
            $query = "SELECT * FROM variure";
            $stmt = $this->connexion->prepare($query);
            $stmt->execute();
        
            $result = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
              extract($row);
        
              $variure = new Variure();
              $variure->setIdVariure($id_variure);
              $variure->setLibelleVariure($libelle_variure);
        
              array_push($result, $variure);
            }
        
            return $result;
          }
      }
      
