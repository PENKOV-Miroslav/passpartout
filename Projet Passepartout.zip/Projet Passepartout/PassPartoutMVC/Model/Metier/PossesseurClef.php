<?php
class PossesseurClef extends Personne{
   
   public function __construct($id_personne ,$nom, $prenom, $numTelephone, $email, $adresse, $code_postale, $login_hash, $mdp_hash, $id_role) {
      parent::__construct($id_personne ,$nom, $prenom, $numTelephone, $email, $adresse, $code_postale);

   }

}