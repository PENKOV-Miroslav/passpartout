<?php
class Batiment{

    private $id_batiment;
    private $nom_batiment;

    public function __construct($id_batiment, $nom_batiment) {
        $this->id_batiment = $id_batiment;
        $this->nom_batiment = $nom_batiment;
    }

    public function getIdBatiment(){
        return $this->id_batiment;
      }
    
      public function setIdBatiment($id_batiment){
        $this->id_batiment = $id_batiment;
      }

    public function getNomBatiment(){
        return $this->nom_batiment;
      }
    
      public function setNomSalle($nom_batiment){
        $this->nom_batiment = $nom_batiment;
      }
}