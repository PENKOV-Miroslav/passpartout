<?php
class Barillet {
    
    private $id_barillet;
    private $code_clef;
    private $stock_clef;
    private $id_variure;

    public function __construct($id_barillet ,$code_clef, $stock_clef, $id_variure) {
        $this->id_barillet = $id_barillet;
        $this->code_clef = $code_clef;
        $this->stock_clef = $stock_clef;
        $this->id_variure = $id_variure;

    }
      
        public function getIdBarillet(){
          return $this->id_barillet;
        }
      
        public function setIdBarillet($id_barillet){
          $this->id_barillet = $id_barillet;
        }
      
        public function getCodeClef(){
          return $this->code_clef;
        }
      
        public function setCodeClef($code_clef){
          $this->code_clef = $code_clef;
        }

              
        public function getStockClef(){
            return $this->stock_clef ;
          }
        
          public function setStockClef($stock_clef){
            $this->stock_clef = $stock_clef;
          }

                
        public function getIdVariure(){
            return $this->id_variure ;
          }
        
          public function setIdVariure($id_variure){
            $this->id_variure = $id_variure;
          }

      }