<?php
class Porte{

    private $id_porte;
    private $id_barillet;

    public function __construct($id_porte, $id_barillet) {
        $this->id_porte = $id_porte;
        $this->id_barillet = $id_barillet;
    }

    public function getPorte(){
        return $this->id_porte;
      }
    
      public function setPorte($id_porte){
        $this->id_porte = $id_porte;
      }

    public function getIdBarillet(){
        return $this->id_barillet;
    }

    public function setIdBarillet($id_barillet){
        $this->id_brarillet = $id_barillet;
    }


}