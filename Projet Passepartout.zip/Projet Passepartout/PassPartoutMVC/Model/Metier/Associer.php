<?php
class Associer{

    private $id_salle;
    private $id_porte; 

    public function __construct($id_salle,$id_porte) {
        $this->id_salle = $id_salle;
        $this->id_porte = $id_porte;
    }

    public function getSalle(){
        return $this->id_salle;
    }

    public function setSalle($id_salle){
        $this->id_salle = $id_salle;
    }

    public function getPorte(){
        return $this->id_exemplaire;
      }
    
      public function setPorte($id_porte){
        $this->id_porte = $id_porte;
      }


}