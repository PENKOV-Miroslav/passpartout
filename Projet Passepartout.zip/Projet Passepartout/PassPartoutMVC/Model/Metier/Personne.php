<?php
class Personne{

    private $id_personne;
    private $nom;
    private $prenom;
    private $numTelephone;
    private $email;
    private $adresse;
    private $code_postale;

    public function __construct($id_personne ,$nom, $prenom, $numTelephone, $email, $adresse, $code_postale) {
        $this->id_personne = $id_personne;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->numTelephone = $numTelephone;
        $this->email = $email;
        $this->adresse = $adresse;
        $this->code_postale = $code_postale;

    }

    public function getIdPersonne(){
        return $this->id_personne;
      }
    
      public function setIdPersonne($id_personne){
        $this->id_personne = $id_personne;
      }

      public function getNom(){
        return $this->nom;
      }
    
      public function setNom($nom){
        $this->nom = $nom;
      }

      public function getPrenom(){
        return $this->prenom;
      }
    
      public function setPrenom($prenom){
        $this->prenom = $prenom;
      }

      public function getNumTelephone(){
        return $this->numTelephone;
      }
    
      public function setNumTelephone($numTelephone){
        $this->numTelephone = $numTelephone;
      }

      public function getEmail(){
        return $this->email;
      }
    
      public function setEmail($email){
        $this->email = $email;
      }

      public function getAdresse(){
        return $this->adresse;
      }
    
      public function setAdresse($adresse){
        $this->adresse = $adresse;
      }

      public function getCodePostale(){
        return $this->code_postale;
      }
    
      public function setCodePostale($code_postale){
        $this->code_postale = $code_postale;
      }
    
}
