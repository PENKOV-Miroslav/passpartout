<?php
class Roles{

    private $id_role;
    private $libelle;

    public function __construct($id_role ,$libelle) {
        $this->id_role = $id_role;
        $this->libelle = $libelle;
    }

    public function getIdRole(){
        return $this->id_personne;
      }
    
      public function setIdRole($id_role){
        $this->id_role = $id_role;
      }

      public function getLibelleRole(){
        return $this->libelle;
      }
    
      public function setLibelleRole($libelle){
        $this->libelle = $libelle;
      }
}