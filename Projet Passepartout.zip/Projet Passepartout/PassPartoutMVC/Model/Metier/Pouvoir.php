<?php

class Pouvoir {
    
    private $id_barillet;
    private $id_personne;


    public function __construct($id_barillet ,$id_personne) {
        $this->id_barillet = $id_barillet;
        $this->id_personne = $id_personne;


    }
      
        public function getIdBarillet(){
          return $this->id_barillet;
        }
      
        public function setIdBarillet($id_barillet){
          $this->id_barillet = $id_barillet;
        }
      
        public function getIdPersonne(){
          return $this->id_personne;
        }
      
        public function setIdPersonne($id_personne){
          $this->id_personne = $id_personne;
        }


      }