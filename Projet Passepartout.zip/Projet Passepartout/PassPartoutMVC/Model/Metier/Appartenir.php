<?php
class Appartenir{

    private $id_barillet;
    private $id_exemplaire;

    public function __construct($id_barillet, $id_exemplaire) {
        $this->id_barillet = $id_barillet;
        $this->id_exemplaire = $id_exemplaire;
    }

    public function getIdBarillet(){
        return $this->id_barillet;
    }

    public function setIdBarillet($id_barillet){
        $this->id_brarillet = $id_barillet;
    }

    public function getIdExemplaire(){
        return $this->id_exemplaire;
      }
    
      public function setIdExemplaire($id_exemplaire){
        $this->id_exemplaire = $id_exemplaire;
      }
}