class Type_Exemplaire{
    constructor(code_type , type_libelle){
        this.code_type = code_type;
        this.type_libelle = type_libelle;
    }

    get getcode_type(){
        return code_type;
    }
    set setcode_type(code_type){
        this.code_type = code_type;
    }

}
module.exports =Type_Exemplaire;
