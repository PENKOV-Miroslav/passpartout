class Exemplaire{

    constructor(idexemplaire, date_aquisition, code_type, idpersonne) {
        this.idexemplaire = idexemplaire;
        this.date_aquisition = date_aquisition;
        this.code_type = code_type;
        this.idpersonne = idpersonne;
      }

      get getidexemplaire() {
        return idexemplaire;
      }
      set setidexemplaire(idexemplaire) {
        this.idexemplaire = idexemplaire;
      }

      get getdate_aquisition() {
        return date_aquisition;
      }
      set setdate_aquisition(date_aquisition) {
        this.date_aquisition = date_aquisition;
      }

      get getcode_type() {
        return code_type;
      }
      set setcode_type(code_type) {
        this.code_type = code_type;
      }

      get getidpersonne() {
        return idpersonne;
      }
      set setidpersonne(idpersonne) {
        this.idpersonne = idpersonne;
      }

}
module.exports = Exemplaire;