class Archivage{

    constructor(idarchive, date_aquisition, date_rendu, idexemplaire, idpersonne ){
        this.idarchive = idarchive;
        this.date_aquisition = date_aquisition;
        this.date_rendu = date_rendu;
        this.idexemplaire = idexemplaire;
        this.idpersonne = idpersonne;

    }

    get getidarchive(){
        return this.idarchive;
    }
    set setidarchive(idarchive){
        this.idarchive = idarchive;
    }

    get getdate_aquisition(){
        return this.date_aquisition;
    }
    set setdate_aquisition( date_aquisition){
        this. date_aquisition = date_aquisition;
    }
}
module.exports = Archivage;