const Personne = require("./personne");

class Possesseur_de_cle extends Personne {
    //constructeur 
    constructor(idpersonne, nom, prenom, numTelephone, email, adresse, codepostal) {
        super(idpersonne, nom, prenom, numTelephone, email, adresse, codepostal);
  
      }

    // getters et setters pour l'attribut
    get getidpersonne() {
        return idpersonne;
      }
    set setidpersonne(idpersonne) {
        this.idpersonne = idpersonne;
      }
}
module.exports = Possesseur_de_cle;