const Personne = require("./personne");

class Utilisateur extends Personne {

    constructor(idpersonne, nom, prenom, numTelephone, email, adresse, codepostal, login_hash,mdp_hash) {
      super(idpersonne, nom, prenom, numTelephone, email, adresse, codepostal);
      this.login_hash = login_hash;
      this.mdp_hash = mdp_hash;
      this.id_role = id_role;

    }

    // getters et setters pour l'attribut
    get getidpersonne() {
        return idpersonne;
      }
    set setidpersonne(idpersonne) {
        this.idpersonne = idpersonne;
      }

      
    get getlogin_hash() {
        return login_hash;
      }
    set setlogin_hash(login_hash) {
        this.login_hash = login_hash;
      }
            
    get getlogin_hash() {
        return login_hash;
      }
    set setlogin_hash(login_hash) {
        this.login_hash = login_hash;
      }
}
module.exports = Utilisateur;