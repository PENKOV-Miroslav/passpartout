class Personne{

  //attribut
  #idpersonne;
  #nom;
  #prenom;
  #numTelephone;
  #email;
  #adresse;
  #codepostal;

  //constructeur 
    constructor() {
      this.#idpersonne = idpersonne;
      this.#nom = nom;
      this.#prenom = prenom;
      this.#numTelephone = numTelephone;
      this.#email = email;
      this.#adresse = adresse;
      this.#codepostal = codepostal;
    }
  
    // getters et setters pour l'attribut
    get getidpersonne() {
      return idpersonne;
    }
    set setidpersonne(idpersonne) {
      this.idpersonne = idpersonne;
    }

    get getnom() {
      return nom;
    }
    set setnom(nom) {
      this.nom = nom;
    }

    get getprenom() {
      return prenom;
    }
    set setprenom(prenom) {
      this.prenom = prenom;
    }

    get getnumTelephone() {
      return numTelephone;
    }
    set setnumTelephone(numTelephone) {
      this.numTelephone = numTelephone;
    }

    get getemail() {
      return email;
    }
    set setemail(email) {
      this.email = email;
    }

    get getadresse() {
      return adresse;
    }
    set setadresse(adresse) {
      this.adresse = adresse;
    }

    get getadresse() {
      return adresse;
    }
    set setcodepostal(codepostal) {
      this.codepostal = codepostal;
    }


  }
  
      
module.exports = Personne;