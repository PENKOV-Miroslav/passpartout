const mysql = require('mysql');

class ConnexionBDD {
  constructor() {
    this.connection = mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'passpartout',
    });
    this.connection.connect((error) => {
      if (error) {
        console.error('Erreur de connexion à la base de données : ', error);
      } else {
        console.log('Connexion à la base de données réussie');
      }
    });
  }

  getConnection() {
    return this.connection;
  }
}

module.exports = new ConnexionBDD();
