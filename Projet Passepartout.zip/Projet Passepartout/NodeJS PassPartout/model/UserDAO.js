const db = require('../config/ConnexionBDD');
const User = require('./entities/user');

class UserDao {
  constructor() {
    this.connection = db.getConnection();
  }

  
    findAll() {
      return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM users';
  
        this.connection.query(query, (error, results) => {
          if (error) {
            reject(error);
          } else {
            const users = [];
  
            for (const row of results) {
              const user = new User(row.id, row.name, row.email, row.password);
              users.push(user);
            }
  
            resolve(users);
          }
        });
      });
    }
  
    findById(id) {
      return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM users WHERE id = ?';
        const values = [id];
  
        this.connection.query(query, values, (error, results) => {
          if (error) {
            reject(error);
          } else if (results.length === 0) {
            resolve(null);
          } else {
            const user = new User(results[0].id, results[0].name, results[0].email, results[0].password);
            resolve(user);
          }
        });
      });
    }
  
    save(user) {
      return new Promise((resolve, reject) => {
        const query = 'INSERT INTO users SET ?';
        const values = {
          id: user.id,
          name: user.name,
          email: user.email,
          password: user.password
        };
  
        this.connection.query(query, values, (error, results) => {
          if (error) {
            reject(error);
          } else {
            resolve(user);
          }
        });
      });
    }
  
    update(user) {
      return new Promise((resolve, reject) => {
        const query = 'UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?';
        const values = [user.name, user.email, user.password, user.id];
  
        this.connection.query(query, values, (error, results) => {
          if (error) {
            reject(error);
          } else {
            resolve(user);
          }
        });
      });
    }
  
    delete(id) {
      return new Promise((resolve, reject) => {
        const query = 'DELETE FROM users WHERE id = ?';
        const values = [id];
  
        this.connection.query(query, values, (error, results) => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        });
      });
    }

  
  


  // CREATE
  createUser(user, callback) {
    const query = 'INSERT INTO users VALUES (?, ?, ?)';
    const values = [user.name, user.email, user.password];

    this.connection.query(query, values, (error, results) => {
      if (error) {
        console.error('Erreur lors de la création de l\'utilisateur : ', error);
        callback(false);
      } else {
        const newUser = new User({
          id: results.insertId,
          username: user.username,
          email: user.email,
          password: user.password,
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        callback(newUser);
      }
    });
  }

  // READ
  getAllUsers(callback) {
    const query = 'SELECT * FROM users';

    this.connection.query(query, (error, results) => {
      if (error) {
        console.error('Erreur lors de la récupération des utilisateurs : ', error);
        callback([]);
      } else {
        const users = results.map((result) => new User(result));
        callback(users);
      }
    });
  }

  getUserById(id, callback) {
    const query = 'SELECT * FROM users WHERE id = ?';
    const values = [id];

    this.connection.query(query, values, (error, results) => {
      if (error) {
        console.error(`Erreur lors de la récupération de l'utilisateur avec l'ID ${id} : `, error);
        callback(null);
      } else {
        const user = results.length > 0 ? new User(results[0]) : null;
        callback(user);
      }
    });
  }

  // UPDATE
  updateUser(user, callback) {
    const query = 'UPDATE users SET username = ?, email = ?, password = ?, updated_at = ? WHERE id = ?';
    const values = [user.name, user.email, user.password, new Date(), user.id];

    this.connection.query(query, values, (error) => {
      if (error) {
        console.error(`Erreur lors de la mise à jour de l'utilisateur avec l'ID ${user.id} : `, error);
        callback(false);
      } else {
        callback(true);
      }
    });
  }

  // DELETE
  deleteUserById(id, callback) {
    const query = 'DELETE FROM users WHERE id = ?';
    const values = [id];

    this.connection.query(query, values, (error) => {
      if (error) {
        console.error(`Erreur lors de la suppression de l'utilisateur avec l'ID ${id} : `, error);
        callback(false);
      } else {
        callback(true);
      }
    });
  }
}
module.exports = UserDao;
