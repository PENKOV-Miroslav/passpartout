const express = require('express')
const app = express()
const port = 3000


app.get('/', function(req, res) {
  res.sendFile(__dirname + '/vue/authentification.html');
});

app.get('/accueil', function(req, res) {
  res.sendFile(__dirname + '/vue/accueil.html');
});


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})