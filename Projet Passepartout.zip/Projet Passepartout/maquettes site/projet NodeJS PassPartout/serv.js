//Settups for the server__________________________________________________________________________________________________________
const express = require('express');
const app = express();
const path = require('path');
const router = express.Router();
//for parsing the body in POST request''''''''''''''''''''''''''''''''''''''''''''
var bodyParser = require('body-parser');
//for the template engine'''''''''''''''''''''''''''''''''''''''''''''''''''''''''
app.set('view engine', 'pug');
//for Image upload''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
var querystring = require("querystring"),
    fs = require("fs"),
    formidable = require("formidable");
var fileName_var;
//configure body-parser for express'''''''''''''''''''''''''''''''''''''''''''''''
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
//configure the css and imgs directory''''''''''''''''''''''''''''''''''''''''''''
app.use(express.static(__dirname + '/views'));
//__________________________________________________________________________________________________________________

//route when no url is entered
//------------------------------------------------------------------------------------------------------------------
router.get('/',function(req,res){
  res.redirect("/oizop1");
});//---------------------------------------------------------------------------------------------------------------

//route for the "connexion" page of the site
//------------------------------------------------------------------------------------------------------------------
router.get('/oizop1',function(req,res){
  console.log('request received for /oizop1');
  res.sendFile(path.join(__dirname+'/views/oizop1.html'));
  console.log('request processing for /oizop1');

  //__dirname : It will resolve to your project folder.
});//---------------------------------------------------------------------------------------------------------------

//route for the welcome page of the site
//-------------------------------------------------------------------------------------------------------------------
app.post('/oizop2', function(req, res){
  //getting the form's info
  nom_POST = req.body.nom

  console.log("paquet POST received from oizop1: "+nom_POST);
  console.log('request received for /oizop2');
  res.render('oizop2', { nom: nom_POST});
  console.log('request processing for /oizop2');
});//---------------------------------------------------------------------------------------------------------------

//route for the upload page of the site
//------------------------------------------------------------------------------------------------------------------
router.get('/oizopupload',function(req,res){
  console.log('request received for /oizopupload');
  res.sendFile(path.join(__dirname+'/views/oizopupload.html'));
  console.log('request processing for /oizopupload');

  //__dirname : It will resolve to your project folder.
});//---------------------------------------------------------------------------------------------------------------

//method for the upload of the picture
//------------------------------------------------------------------------------------------------------------------
app.post('/oizopupload2', function(req, res){
  var form = new formidable.IncomingForm();
  console.log("file POST received from oizopupload");
  form.parse(req, function(error, fields, files) {
    fileName_var = files.upload.originalFilename;
    console.log("Process ended");
    /* En cas d'erreur sous Windows :
       tentative d'écrasement d'un fichier existant */
      fs.rename(files.upload.filepath, "views/images/"+fileName_var, function(err) {
      if (err) {
        fs.unlink("views/images/"+fileName_var);
        fs.rename(files.upload.filepath, "views/images/"+fileName_var);
      }
    });
    console.log("file transfered");
    res.redirect("/oizopupload");
  });
});//---------------------------------------------------------------------------------------------------------------

//route for the project gestion page
//------------------------------------------------------------------------------------------------------------------
router.get('/gestion',function(req,res){
  console.log('request received for /gestion');
  res.sendFile(path.join(__dirname+'/views/gestion.html'));
  console.log('request processing for /gestion');

  //__dirname : It will resolve to your project folder.
});//---------------------------------------------------------------------------------------------------------------

//____________________________________________________________________________________________________________________
//add the router
app.use('/', router);
app.listen(process.env.port || 10000);
console.log('Server running at Port 10 000');
//_____________________________________________________________________________________________________________________
// DOC pour express
// https://codeforgeek.com/render-html-file-expressjs/